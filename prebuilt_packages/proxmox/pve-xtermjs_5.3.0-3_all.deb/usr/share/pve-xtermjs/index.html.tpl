<!doctype html>
<html>
    <head>
	<title>[% nodename %] - Proxmox Console</title>
	<link rel="stylesheet" href="/xtermjs/xterm.css?version=5.3.0-3" />
	<link rel="stylesheet" href="/xtermjs/style.css?version=5.3.0-3" />
	<script src="/xtermjs/xterm.js?version=5.3.0-3" ></script>
	<script src="/xtermjs/xterm-addon-fit.js?version=5.3.0-3" ></script>
	<script src="/xtermjs/xterm-addon-webgl.js?version=5.3.0-3" ></script>
	<script src="/xtermjs/util.js?version=5.3.0-3" ></script>
    </head>
    <body>
	<div id="status_bar"></div>
	<div id="wrap">
	<div class="center">
	    <div id="connect_dlg">
		<div id="pve_start_info">Guest not running</div>
		<div id="connect_btn"><div> Start Now </div></div>
	    </div>
	</div>
	<div id="terminal-container"></div>
	</div>
	<script type="text/javascript">
	    if (typeof(PVE) === 'undefined') PVE = {};
	    PVE.UserName = '[% username %]';
	    PVE.CSRFPreventionToken = '[% token %]';
	</script>
	<script src="/xtermjs/main.js?version=5.3.0-3" defer ></script>
    </body>
</html>
